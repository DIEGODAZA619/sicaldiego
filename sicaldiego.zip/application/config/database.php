<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$active_group = 'db_almacen';
$query_builder = TRUE;

/*$db['db_entorno'] = array(
	'dsn'	=> '',
	'hostname' => 'localhost',
	'password' => '1982',
	'username' => 'postgres',	
	'database' => 'db_entorno_oficial',
	'dbdriver' => 'postgre',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(), 
	'save_queries' => TRUE,
	'port' => '5433'
);

//RECURSOS HUMANOS
$db['db_recursos_humanos'] = array(
	'dsn'	=> '',	
	'hostname' => 'localhost',
	'password' => '1982',
	'username' => 'postgres',
	'database' => 'db_sigap_oficial',
	'dbdriver' => 'postgre',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(), 
	'save_queries' => TRUE,
	'port' => '5433'
);

//RECURSOS HUMANOS
$db['db_almacen_POS'] = array(
	'dsn'	=> '',	
	'hostname' => 'localhost',
	'password' => '1982',
	'username' => 'postgres',
	'database' => 'db_sical_oficial',
	'dbdriver' => 'postgre',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(), 
	'save_queries' => TRUE,
	'port' => '5433'
);*/

$db['db_almacen'] = array(
	'dsn'	=> '',
	'hostname' => 'localhost',
	'username' => 'root',
	'password' => '',
	'database' => 'sicaldidi',
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

//Usuario: aldidacom_x

//Base de datos: aldidacom_sical

//Sical19822023
