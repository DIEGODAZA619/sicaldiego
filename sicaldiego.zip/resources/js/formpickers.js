(function($) {
  'use strict';
  $('.datepicker').datepicker();
  $('.datepicker-autoclose').datepicker({
    autoclose: true
  })
})(jQuery);
